package p1;

public interface Tr1_Wallace {
	
	// method that prints
	default void printName() {
		System.out.println("Triangle Interface");
 	}
}