package p1;

public abstract class Shape {
	public String shape;
	
 	// set shape name method
	public void setShape(String shape) {
	    this.shape = shape;
	}

	// get shape name abstract method
	public abstract String getShape();
	
}