Simple JavaScript Calculator
============================

This is a basic calculator built using HTML, CSS, and JavaScript. 
It can perform:
- Arithmetic operations
- Percentages
- Squaring
- Square Roots
- Reciprocal
- Sign Changes

The calculator features a history display, a clear all button (C), a clear entry button (CE), and a backspace button (⌫).


